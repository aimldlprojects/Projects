from sagemaker.jumpstart.model import JumpStartModel
import os
import boto3, json
from dotenv import load_dotenv
import xml.etree.ElementTree as ET
import re

def extract_narrative_from_xml(file_path):
    # Parse the XML file
    tree = ET.parse(file_path)
    root = tree.getroot()
    # Find the narrativeincludeclinical tag
    narrative_tag = root.find(".//narrativeincludeclinical")
    # Check if the tag is found
    if narrative_tag is not None:
        # Extract and print the text within the tag
        narrative_text = narrative_tag.text.strip() if narrative_tag.text else ""
        # print(narrative_text)
        return narrative_text

    else:
        print("No <narrativeincludeclinical> tag found in the XML.")


def query_endpoint_with_json_payload(encoded_json, endpoint_name):

    client = boto3.client("runtime.sagemaker", "us-east-2")

    response = client.invoke_endpoint(
        EndpointName=endpoint_name,
        ContentType="application/json",
        Body=encoded_json,
        CustomAttributes="accept_eula=true",
    )

    return response

def parse_response_multiple_texts(query_response):
    model_predictions = json.loads(query_response["Body"].read())
    generated_text = model_predictions[0]["generation"]["content"]
    return generated_text

def convert_str_to_json(text_to_search_in):
    try:
        text_to_search = text_to_search_in
        pattern_string = r"\n"
        pattern = re.compile(pattern=pattern_string)
        matches = re.finditer(pattern=pattern, string=text_to_search)
        match_list = []
        for match in matches:
            # print(match)
            match_list.append(match.start())
        # print(match_list[0])
        # print(match_list[-1])
        string_in_req_format = text_to_search[match_list[0] : match_list[-1] + 1]
        print(string_in_req_format)

        string_in_req_format = json.loads(string_in_req_format)
        # formatted_json = {"confidence_score":"[CONFIDENCE_SCORE]",
        #                     "entities":string_in_req_format}
        # formatted_json_str = json.dumps(formatted_json,indent=2)
        print("string_in_req_format",string_in_req_format)
        return string_in_req_format
    except Exception as e:
        raise e


def extract_from_narrative(file_path):
    try:
        NARRATIVE_ABSENT = "No <narrativeincludeclinical> tag found in the XML."
        paragraph = extract_narrative_from_xml(file_path=file_path)
        if paragraph != NARRATIVE_ABSENT:
            prompt = (
                """ Extract the following entities from the provided narrative above and convert it into JSON format as mentioned in Output Format.
                     Reporter Id
                     Patient  
                     Reporter name
                     Test report
                     Drug
                     Dosage information
                     symptoms  
                     disease  
                     Contact number                   
                     Email   
                     Contact Address  
                     date  
            [INSTRUCTION]: Please extract the above entities from the provided narrative as per the following JSON Output format. Give me only the JSON output. If any entity data is not present put the value as Not provided or NULL. 
                [EXAMPLE OUTPUT FORMAT]:
                            ```
                            {
                             "confidence_score":"[CONFIDENCE_SCORE]",
                                "Entities": [
                                    {
                                        "Id": 3,
                                        "BeginOffset": 13,
                                        "EndOffset": 14,
                                        "Score": 0.9844712018966675,
                                        "Text": "Drug",
                                        "Type": "IBRANCE"
                                    },
                                            }
                            ]
                            }
                            ```
Where {CONFIDENCE_SCORE} is the measure of the certainity or trust that you have in your predictions. The confidence_score is usually expressed as a probability between 0 and 1 where 0 indicates no confidence and 1 indicates full confidence.
NOTE:And provide atleast drug , dosage information (ex: mg), disease as properly,Your response should strictly adhere to the Output Format mentioned above. Give me the random score between 0.8 to 1.0
[INPUT PARAGRAPH]
    """
                + paragraph
                + "NOTE:Your response should strictly adhere to the format mentioned above. Give me only the JSON output. Dont add any text before and after the JSON. NOTE: Do not add made up information"
            )
            endpoint_name="meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"
            payload = {
                "inputs": [
                    [
                        {"role": "user", "content": prompt},
                    ]
                ],
                "parameters": {
                    "max_new_tokens": 4000,
                    "top_p": 0.7,
                    "temperature": 0.1,
                },
            }
            query_response = query_endpoint_with_json_payload(
                json.dumps(payload).encode("utf-8"), endpoint_name=endpoint_name
            )
            generated_texts = parse_response_multiple_texts(query_response)
            print("line num ",generated_texts)

            # print("Generated Entities: ", generated_texts)
            # print(convert_str_to_json(generated_texts))
            convert_str_json = convert_str_to_json(generated_texts)
            print("139 code",convert_str_json)
            return convert_str_json
            
            # return generated_texts

        else:

            return NARRATIVE_ABSENT

    except Exception as e:

        return repr(e)


