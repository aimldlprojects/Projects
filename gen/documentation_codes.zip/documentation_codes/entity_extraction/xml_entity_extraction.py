from fastapi import FastAPI
from pydantic import BaseModel
import xml.etree.ElementTree as ET
from sagemaker.jumpstart.model import JumpStartModel
from dotenv import load_dotenv
from botocore.config import Config
import os
import boto3, json
import uvicorn
import re
from fastapi.responses import JSONResponse

# app = FastAPI()

def read_xml_file(file_path):
    try:

        with open(file_path, "r", encoding="utf-8") as xml_file:

            xml_text = xml_file.read()

            return xml_text

    except FileNotFoundError:

        return f"XML file not found at '{file_path}'"

    except Exception as e:

        return f"An error occurred: {str(e)}"

def chunk_xml(xml_string, max_chunk_size, target_tags):

    root = ET.fromstring(xml_string)

    current_chunk = ET.Element(root.tag)

    current_chunk_size = 0

    chunks = []

    for element in root.iter():

        if element.tag in target_tags:

            element_str = ET.tostring(element, encoding="utf-8").decode(
                "utf-8", errors="ignore"
            )

            # Check if adding the current element exceeds the max_chunk_size

            if current_chunk_size + len(element_str) > max_chunk_size:

                chunks.append(current_chunk)

                current_chunk = ET.Element(root.tag)

                current_chunk_size = 0

            # Append the current element to the current chunk

            current_chunk.append(element)

            current_chunk_size += len(element_str)

    # Append the last chunk if it's not empty

    if len(current_chunk) > 0:

        chunks.append(current_chunk)

    chunk_strings = [
        ET.tostring(chunk, encoding="utf-8").decode("utf-8", errors="ignore")
        for chunk in chunks
    ]

    return chunk_strings

def write_chunks_to_files(chunks):
    for i, chunk in enumerate(chunks):
        with open(f"./app/data/chunked_xml/output_chunk_{i + 1}.xml", "w") as file:
            file.write(chunk)

def query_endpoint_with_json_payload(encoded_json, endpoint_name):
    client = boto3.client("runtime.sagemaker", "us-east-2")
    response = client.invoke_endpoint(
        EndpointName=endpoint_name,
        ContentType="application/json",
        Body=encoded_json,
        CustomAttributes="accept_eula=true",
    )
    return response

def parse_response_multiple_texts(query_response):
    model_predictions = json.loads(query_response["Body"].read())
    generated_text = model_predictions[0]["generation"]["content"]
    return generated_text

def convert_str_to_json(text_to_search_in):
    try:
        text_to_search_in = text_to_search_in
        format_text_cur_open = [
            corrected_json_string.span()
            for corrected_json_string in re.finditer("{", text_to_search_in)
        ]

        format_text_cur_close = [
            corrected_json_string.span()
            for corrected_json_string in re.finditer("}", text_to_search_in)
        ]

        if len(format_text_cur_open) != len(format_text_cur_close):

            text_to_search_in = text_to_search_in + "\n}"

        format_text_sq_open = [
            corrected_json_string.span()
            for corrected_json_string in re.finditer("\[", text_to_search_in)
        ]

        format_text_sq_close = [
            corrected_json_string.span()
            for corrected_json_string in re.finditer("\]", text_to_search_in)
        ]

        if len(format_text_sq_open) != len(format_text_sq_close):

            text_to_search_in = (
                text_to_search_in[: len(text_to_search_in) - 1]
                + "\n]"
                + text_to_search_in[len(text_to_search_in) - 1 :]
            )

        format_text = text_to_search_in

        print("curly", len(format_text_cur_open), len(format_text_cur_close))

        print("sq", len(format_text_sq_open), len(format_text_sq_close))

        # print("---------------------")

        # print(format_text)

        return format_text

    except Exception as e:

        raise e

def find_non_character_and_empty_lines(text):

    non_character_and_empty_lines = []

    for line in text.split("\n"):

        # Use regular expression to check if the line is either empty or does not contain any alphabetic characters

        if not re.search(r"[a-zA-Z]", line) or not line.strip():

            non_character_and_empty_lines.append(line)

    return non_character_and_empty_lines

def separate_text_into_lists(multiline_text):

    # Split the multiline text based on empty lines

    sections = [section.strip().split("\n") for section in multiline_text.split("\n\n")]

    # Remove empty sections

    sections = [section for section in sections if section]

    return sections

def process_text(text):

    processed_lines = []

    for line in text.split("\n"):

        # Check if the line is either empty or does not contain any alphabetic characters

        if not re.search(r"[a-zA-Z]", line) or not line.strip():

            # If the line has special characters, replace it with an empty line

            if re.search(r"\W", line):

                processed_lines.append("")

            else:

                processed_lines.append(line)

        else:

            processed_lines.append(line)

    return "\n".join(processed_lines)



def generate_valid_json(json_string):
    try:
        processed_text = process_text(json_string)
        result_lists = separate_text_into_lists(processed_text)
        new_entity = []

        for i, section in enumerate(result_lists, start=1):
            section = " ".join(section)
            section = "\n".join(line for line in section.split("\n") if "Note that" not in line)

            format_text_cur_open = [corrected_json_string.span() for corrected_json_string in re.finditer("{", section)]

            if len(format_text_cur_open) == 1:
                section = section + "}"
            elif len(format_text_cur_open) == 2:
                section = section + "}}"

            section = re.findall(pattern=r'"[\w]+.*:.*', string=section)

            if section:
                new_entity.append(section[0])

        entity_new = []

        for j, value in enumerate(new_entity):
            if value:
                if j == 0:
                    entity_new.append("{" + value)
                elif j == len(new_entity) - 1:
                    entity_new.append("{" + value + "}")
                elif j == len(new_entity):
                    entity_new.append("{" + value + "}")
                else:
                    entity_new.append("{" + value + "},")

        entity_new = "".join(entity_new) + "]}"

        # Ensure proper curly braces for each line
        entity_new_lines = []
        for line in entity_new.split('\n'):
            line = "{" + line[1:] if not line.startswith("{") else line
            line = line[:-1] + "}" if not line.endswith("}") else line
            entity_new_lines.append(line)

        entity_new = "\n".join(entity_new_lines)
        # print(entity_new)

        return json.loads(entity_new)

    except Exception as e:
        raise e



def extract_from_xml(file_path):

    try:

        xml_data = open(file_path).read()

        max_chunk_size = 4090

        target_tags = [
            "patient",
            "drug",
            "test",
            "drugeventmatrix",
            "reporter",
            "history",
        ]

        chunks = chunk_xml(xml_data, max_chunk_size, target_tags)

        # Write chunks to XML files

        write_chunks_to_files(chunks)

        generated_text_list = []

        for i, chunk in enumerate(chunks):

            file_path = (
                f"./app/data/chunked_xml/output_chunk_{i + 1}.xml"
            )

            xml_content = read_xml_file(file_path)

            if not xml_content.startswith("XML file not found"):
                pass

            else:
                pass

           

            prompt = (
                """ Extract the following entities from the XML content provided below and convert it into JSON format as mentioned in Output Format.
                     Reporter name
                     Reporter email
                     Patient
                     Drug
                     Dosage information
                     Test  
                     History
                     Events
                     Symptoms
                     Email
                     Contact number
                     Address          
            [INSTRUCTION]: Please extract the above entities from the XML content and list them as per the following JSON Output format.Give me only the JSON output. Dont add any text before and after the JSON. If for any entity data is not present put the value as NULL. Use the following Format as example and give the extracted entities as json format.
            [OUTPUT FORMAT]:
```          
    {{
    "confidence_score":"[CONFIDENCE_SCORE]",
        "entities": [
        "Reporter": {{
               [...]
                }},
        "patient": {{
               [...]}},
        "drug": {{
            "druguniversallyuniqueid": "druguniversallyuniqueid",
            "drugcharacterization": "drugcharacterization",
            "medicinalproduct": "medicinalproduct",
        }},
        "dosageinformation":{{
                [...]
                                }},
        "history":{{
                "patientmedicalhistorytext":"patientweight",
                }},
        "drugeventmatrix": [
                    {{
                        "eventuniversallyuniqueid": "eventuniversallyuniqueid",
                        "drugstartperiod": "drugstartperiod",
                        "drugstartperiodunit": "drugstartperiodunit"
                    }},
                   {{
                        "eventuniversallyuniqueid": "eventuniversallyuniqueid",
                        "drugstartperiod": "drugstartperiod",
                        "drugstartperiodunit": "drugstartperiodunit"
                    }},            
                ],                
        "test": {{
                [...]
            }},
        ]
    }}        
```
Where {CONFIDENCE_SCORE} is the measure of the certainity or trust that you have in your predictions. The confidence_score is usually expressed as a probability between 0 and 1 where 0 indicates no confidence and 1 indicates full confidence.give some random confidence score from the model.
NOTE:Your response should strictly adhere to the Output Format mentioned above.
[XML CONTENT]
    """
                + xml_content
                + "NOTE:Your response should strictly adhere to the format mentioned above. Give me only the JSON output. Dont add any text before and after the JSON. NOTE: Do not add made up information "
            )

            # print(prompt)

            endpoint_name = "meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"

            payload = {
                "inputs": [
                    [
                        {"role": "user", "content": prompt},
                    ]
                ],
                "parameters": {
                    "max_new_tokens": 4000,
                    "top_p": 0.7,
                    "temperature": 0.1,
                },
            }
            query_response = query_endpoint_with_json_payload(
                json.dumps(payload).encode("utf-8"), endpoint_name=endpoint_name
            )
            generated_texts = parse_response_multiple_texts(query_response)
            # print("line num 468",generated_texts)
            generated_text_list.append(generate_valid_json(generated_texts))
        return generated_text_list

    except Exception as e:
        print("error:")
        print(repr(e))
        raise e

# def process_json(generated_text_list):
#     data_list = generated_text_list 
#     return data_list[0]

def parse_and_standardize(json_data:dict):
    # json_data = generated_text_list
    if "entities" in json_data:
        entities = json_data["entities"]
        for entity in entities:
            if "properties" in entity:
                properties = entity["properties"]
                entity["properties"] = remove_underscores(properties)
            elif "data" in entity:
                data = entity["data"]
                entity["data"] = remove_underscores(data)
    # json_data["entities"]= entities
    return json_data


def remove_underscores(data):
    if isinstance(data, dict):
        return {key.replace('_', ''): remove_underscores(value) for key, value in data.items()}
    elif isinstance(data, list):
        return [remove_underscores(item) for item in data]
    else:
        return data



