from fastapi import FastAPI
from pydantic import BaseModel
import xml.etree.ElementTree as ET
# from sagemaker.jumpstart.model import JumpStartModel
from dotenv import load_dotenv
from botocore.config import Config
import os
import boto3, json
import uvicorn


def query_endpoint_with_json_payload(encoded_json, endpoint_name):

    client = boto3.client("runtime.sagemaker", "us-east-2")
    response = client.invoke_endpoint(
        EndpointName=endpoint_name, ContentType="application/json", Body=encoded_json, CustomAttributes='accept_eula=true'
    )
    return response

def parse_response_multiple_texts(query_response):

    model_predictions = json.loads(query_response["Body"].read())
    generated_text = model_predictions[0]['generation']["content"]
    return generated_text


def update_prompt(query):
    prompt = f"""
           [INST]<<SYS>> Generate a comprehensive medical narrative that accurately reflects the patient information provided in the following dictionary values. Prioritize factual accuracy, clarity, completeness, logical structure, and contextual awareness. Make sure not to repeat the same sentences in the generated narrative. Adhere to medical terminology and conventions, and maintain patient confidentiality.Don't repeat the narrative again, strict with the single time. <</SYS>>{query}[/INST]
      
    """
    return prompt


def perform_narrative_generation(narrative_gen_inputs):
    try:
        prompt = update_prompt(query=narrative_gen_inputs)
        endpoint_name="meta-textgeneration-llama-2-7b-f-2023-11-09-14-39-45-878"
        

        payload = {
            "inputs": [[
                {"role": "user", "content": prompt},
            ]],
            "parameters": {"max_new_tokens": 800,  "top_p": 0.7, "temperature": 0.1}
        }
        query_response = query_endpoint_with_json_payload(
            json.dumps(payload).encode("utf-8"), endpoint_name=endpoint_name
        )
        generated_texts = parse_response_multiple_texts(query_response)
        return {'status_code':'200','Message':'Narrative generation successful','response_body':generated_texts}
    except Exception as e:
        return {'status_code':'400','Message':'Narrative generation failed','Error':repr(e)}