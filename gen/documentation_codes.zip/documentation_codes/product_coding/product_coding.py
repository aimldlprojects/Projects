@app.post("/productcode", tags=["Map the Product Code"])
def execute_product_code(details: InputsProductCode):
    try:
        data = []
 
        data.append({"medicinalproduct": details.medicinalproduct})
 
        # Create a dataframe from the list of dictionaries
        df_drug = pd.DataFrame(data)
 
        # Load the second Excel file with the "MAKTX" and "MATNR" columns
        df_product = pd.read_excel(r"./app/productcode.xlsx")
 
        # Function to find similar matches using TF-IDF and cosine similarity
        def find_similar_matches(
            row, tfidf_vectorizer, tfidf_matrix_product, df_product
        ):
            query_tfidf = tfidf_vectorizer.transform([row["medicinalproduct"]])
            cosine_similarities = cosine_similarity(
                query_tfidf, tfidf_matrix_product
            ).flatten()
            similar_indices = cosine_similarities.argsort()[
                :-2:-1
            ]  # Get the most similar index (excluding itself)
            return df_product.iloc[similar_indices[0]]
 
        # Apply TF-IDF vectorization to both dataframes
        vectorizer = TfidfVectorizer()
        tfidf_matrix_drug = vectorizer.fit_transform(df_drug["medicinalproduct"])
        tfidf_matrix_product = vectorizer.transform(df_product["MAKTX"])
 
        # Apply similar match function
        result_df = df_drug.apply(
            find_similar_matches,
            axis=1,
            tfidf_vectorizer=vectorizer,
            tfidf_matrix_product=tfidf_matrix_product,
            df_product=df_product,
        )
 
        # Merge the results
        merged_df = pd.concat([df_drug, result_df], axis=1, join="inner")
 
        # Check if the merged dataframe is not empty before printing
        if not merged_df.empty:
            # Display the resulting dataframe with matching fields and corresponding 'MATNR' values
            result_df = merged_df[["medicinalproduct", "MAKTX", "MATNR"]]
 
            # Convert the DataFrame to a list of dictionaries
            result_list = result_df.to_dict(orient="records")
 
            # Remove the entry with key '0'
            result_list_without_zeros = [entry for entry in result_list if entry["medicinalproduct"] != 0]
 
            # Return the modified result
            return {"message": result_list_without_zeros}
 
        else:
            return "No matching data found."
 
    except Exception as e:

        raise Exception(repr(e))
